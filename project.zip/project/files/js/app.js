var instagram=function(){
    var appname='اینستاگرام' , devname='متا', logo='https://store-images.s-microsoft.com/image/apps.31997.13510798887167234.6cd52261-a276-49cf-9b6b-9ef8491fb799.30e70ce4-33c5-43d6-9af1-491fe4679377?h=210';
    document.getElementById('tapn').innerHTML=appname;
    document.getElementById('tden').innerHTML=devname;
    document.getElementById('tlog').src=logo;
    document.getElementById('apn').innerHTML=appname;
    document.getElementById('den').innerHTML=devname;
    document.getElementById('log').src=logo;
}

var bale=function(){
    var appname='پیام رسان بله', devname='پلتفرم مالی و اجتماعی بله' , logo='https://bale.ai/_next/image?url=%2Fuploads%2Fbale.png&w=1200&q=75';
    document.getElementById('tapn').innerHTML=appname;
    document.getElementById('tden').innerHTML=devname;
    document.getElementById('tlog').src=logo;
    document.getElementById('apn').innerHTML=appname;
    document.getElementById('den').innerHTML=devname;
    document.getElementById('log').src=logo;
    }

    var baam=function(){
        var appname='بام ، پلتفرم دیجیتال بانک ملی ایران', devname='شرکت داده ورزی سداد' , logo='https://s.cafebazaar.ir/images/icons/ir.bmi.bam.nativeweb-381e924a-6ccb-474b-a44e-e4177a37373f_128x128.png?x-img=v1/format,type_webp,lossless_true/resize,h_128,w_128,lossless_true';
        document.getElementById('tapn').innerHTML=appname;
        document.getElementById('tden').innerHTML=devname;
        document.getElementById('tlog').src=logo;
        document.getElementById('apn').innerHTML=appname;
        document.getElementById('den').innerHTML=devname;
        document.getElementById('log').src=logo;
        }